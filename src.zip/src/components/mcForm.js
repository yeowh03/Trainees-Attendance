import Button from 'react-bootstrap/Button'
import React, {useState} from "react"
import { useLocation, useNavigate } from "react-router-dom"

function MCForm(props) { 
    const location = useLocation()
    const navigate = useNavigate()
    const [id, setid] = useState(location.state.leave.id.toString())
    const [startDate, setstartDate] = useState(location.state.leave.startDate)
    const [endDate, setendDate] = useState(location.state.leave.endDate)
    const [leave_id, setleave_id] = useState(location.state.leave.leave_id)
    const [type, settype] = useState(location.state.leave.type)
    const [inCamp, setinCamp] = useState(location.state.leave.inCamp)
    const [active, setactive] = useState(location.state.leave.active)
    const [errors, seterrors] = useState({})
    const [isOthers, setisOthers] = useState(type!=="MC" && type!=="LD" && type!=="RMJ" ? true : false)

    const [updateMC, setupdateMC] = useState((type === "MC" && id) ? true : false)
    const [updateLD, setupdateLD] = useState(type === "LD" && id ? true : false)
    const [updateRMJ, setupdateRMJ] = useState(type === "RMJ" && id ? true : false)
    const [updateOthers, setupdateOthers] = useState(id ? true : false)

    const validateForm = (type) => {
        let errors_dic = {}
        if (!id || id.length !== 4 || isNaN(id)) errors_dic.id = "Invalid ID."

        if (!startDate) errors_dic.startDate = "Start Date is required."
        
        if (!endDate) {errors_dic.endDate = "End Date is required."}

        if (type.length === 0) {errors_dic.type = "Type is required."}

        if (isOthers) {
            if (inCamp === "") {errors_dic.inCamp = "In Camp field is required."}
            if (active === "") {errors_dic.active = "Active field is required."}
            if (active && !inCamp) {errors_dic.active = "Cannot be active but absent"}
        }

        let date1=new Date(startDate)
        let date2=new Date(endDate)
      
        if (date1>date2) {
            errors_dic.endDate = "Start Date cannot be later than End Date."
            
        }

        seterrors(errors_dic)
        return Object.keys(errors_dic).length === 0
    }

    const handleMCSubmit = (props) => {
        console.log(updateMC, "updateMC")
        if (validateForm(type)) {

            if (updateMC) {
                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_mc", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, leave_id:leave_id})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/MCToday")
                })
                .catch(error => 
                    console.log(error)
                )

            } else {
                console.log("Successful came to ADD")

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_mc", {
                    method:"POST",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, type:"MC"})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/MCToday")
                })
                .catch(error => 
                    console.log(error)
                )
            }
        }

        else {
            console.log("UnSuccessful")
        }    
    }

    const handleLDSubmit = (props) => {
        console.log(updateLD, "updateLD")
        if (validateForm(type)) {

            if (updateLD) {
                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_ld", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, leave_id:leave_id})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/LDToday")
                })
                .catch(error => 
                    console.log(error)
                )

            } else {
                console.log("Successful came to ADD")

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_ld", {
                    method:"POST",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, type:"LD"})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/LDToday")
                })
                .catch(error => 
                    console.log(error)
                )
            }
        }

        else {
            console.log("UnSuccessful")
        }    
    }

    const handleRMJSubmit = (props) => {
        console.log(updateRMJ, "updateRMJ")
        if (validateForm(type)) {

            if (updateRMJ) {
                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_rmj", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, leave_id:leave_id})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/RMJToday")
                })
                .catch(error => 
                    console.log(error)
                )

            } else {
                console.log("Successful came to ADD")

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_rmj", {
                    method:"POST",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, type:"RMJ"})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/RMJToday")
                })
                .catch(error => 
                    console.log(error)
                )
            }
        }

        else {
            console.log("UnSuccessful")
        }    
    }

    const handleOthersSubmit = (props) => {
        if (validateForm(type)) {

            if (updateOthers) {
                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_others", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, leave_id:leave_id, type:type, inCamp:inCamp, active:active})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/OthersToday")
                })
                .catch(error => 
                    console.log(error)
                )

            } else {
                console.log("Successful came to ADD")

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_others", {
                    method:"POST",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, startDate:startDate, endDate:endDate, leave_id:leave_id, type:type, inCamp:inCamp, active:active})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/OthersToday")
                })
                .catch(error => 
                    console.log(error)
                )
            }
        }

        else {
            console.log("UnSuccessful")
        }    
    }
    
    return (
        <div>
            <div className="mb-3">
                <label htmlFor="id" className="form-label">4D</label>
                <input type="text" style={{marginBottom:"10px"}} className="form-control" placeholder="1301" value={id.toString()} onChange={(e) => setid(e.target.value)}/>
                {errors.id ? <p style={{paddingLeft:10, color:"red"}}>{errors.id}</p> : null}
                
                <label htmlFor="startdate" className="form-label">Start Date</label>
                <input type="date" style={{marginBottom:"10px"}} className="form-control" placeholder="1/1/24" value={startDate} onChange={(e) => setstartDate(e.target.value)}/>
                {errors.startDate ? <p style={{paddingLeft:10, color:"red", marginVertical:-5}}>{errors.startDate}</p> : null}
                
                <label htmlFor="enddate" className="form-label">End Date</label>
                <input type="date" style={{marginBottom:"10px"}} className="form-control" placeholder="3/1/24" value={endDate} onChange={(e) => setendDate(e.target.value)}/>
                {errors.endDate ? <p style={{paddingLeft:10, color:"red", marginVertical:-5}}>{errors.endDate}</p> : null}

                {isOthers && (<label htmlFor="type" className="form-label">Reason</label>)}               
                {isOthers && (<input type="text" style={{marginBottom:"10px"}} className="form-control" placeholder="Late" value={type} onChange={(e) => settype(e.target.value)}/>)}
                {errors.type ? <p style={{paddingLeft:10, color:"red"}}>{errors.type}</p> : null}

                {isOthers && <label htmlFor="inCamp" className="form-label">In Camp</label>}<br></br>
                {isOthers && <input type="radio" name="inCamp" value={true} id="incamp" onChange={e=>setinCamp(true)} checked={inCamp && inCamp!==""}/>}
                {isOthers && <label htmlFor="incamp" style={{margin:10}}>Yes</label>}
                {isOthers && <input type="radio" name="inCamp" value={false} id="notincamp" onChange={e=>setinCamp(false)} checked={!inCamp && inCamp!==""}/>}
                {isOthers && <label htmlFor="notincamp" style={{margin:10}}>No</label>} <br/>
                {errors.inCamp ? <p style={{paddingLeft:10, color:"red"}}>{errors.inCamp}</p> : null}

                {isOthers && <label htmlFor="active" className="form-label">Active</label>}<br></br>
                {isOthers && <input type="radio" name="active" value={true} id="active" onChange={e=>setactive(true)} checked={active && active!==""}/>}
                {isOthers && <label htmlFor="active" style={{margin:10}}>Yes</label>}
                {isOthers && <input type="radio" name="active" value={false} id="notactive" onChange={e=>setactive(false)} checked={!active && active!==""}/>}
                {isOthers && <label htmlFor="notactive" style={{margin:10}}>No</label>}
                {errors.active ? <p style={{paddingLeft:10, color:"red"}}>{errors.active}</p> : null}

                <div className="d-grid gap-2">
                    {type==="MC" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleMCSubmit}>Submit</Button>
                    }

                    {type==="LD" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleLDSubmit}>Submit</Button>
                    }
                    
                    {type==="RMJ" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleRMJSubmit}>Submit</Button>
                    }

                    {isOthers && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleOthersSubmit}>Submit</Button>
                    }

                </div>
            </div>

            <div className="d-grid gap-2">
                    <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate(-1)}>Back</Button>
            </div>  
        </div>
    )
}
export default MCForm