import React, { useEffect, useState } from "react"
import { Fab, Action } from 'react-tiny-fab';
import { IoIosAdd } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import Button from 'react-bootstrap/Button'

function RSOToday(props) {

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const deleteRSO = (id) => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_rso", {
            method:"PUT",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({id:id})
        })
            .then(resp => resp.json())
            .then(data => loadData())
            .catch(error => {
                console.log(error)
            
            })       
    }

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_rso", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(rso=>{
            setData(rso)
        })
        .catch(error=>console.log(error))
      }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div>
            <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate("/")}>Back</Button>
            <h1 align="center">RSO</h1>
            <p align="center" style={{fontSize:"20px"}}>Total: {data.length}</p>
            {data && data.map(rso => {
                return (
                    <div key={rso.id}>
                        <h5>{rso.id} {rso.name}</h5>

                        <div className="row">
                            <div className="col-4">
                                <button className="btn btn-danger"
                                onClick={() => deleteRSO(rso.id)}
                                >Delete</button>                  
                            </div>
                        </div>
                        <hr></hr>
                    </div>
                )
            })}
            <Fab mainButtonStyles={{backgroundColor:"orange"}} style={{bottom:5, right:5}}
            icon={<IoIosAdd style={{color:"white"}}/>}
            onClick={() => {
                navigate("/idOnlyForm", {state:{leave:{id:"", type:"RSO"}}})
            }}
            />
        
        </div>
        
    )
}

export default RSOToday