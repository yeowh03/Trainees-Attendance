import React, { useEffect, useState } from "react"
import { useNavigate, useRoutes } from "react-router-dom";
import Button from 'react-bootstrap/Button'
import BasicExample from "./navbar";

function StatusToday(props) {

    const navigate = useNavigate()
    const [company, setcompany] = useState([])
    const [mc, setmc] = useState([])
    const [ld, setld] = useState([])
    const [others, setothers] = useState([])
    const [esi, setesi] = useState([])
    const [rmj, setrmj] = useState([])
    const [rso, setrso] = useState([])
    const [timeoff, settimeoff] = useState([])
    const [remarks, setremarks] = useState([])

    const [totalPltOne, settotalPltOne] = useState(0)
    const [totalPltTwo, settotalPltTwo] = useState(0)
    const [totalPltThree, settotalPltThree] = useState(0)

    const [currentPltOne, setcurrentPltOne] = useState(0)
    const [currentPltTwo, setcurrentPltTwo] = useState(0)
    const [currentPltThree, setcurrentPltThree] = useState(0)

    const[activePltOne, setactivePltOne] = useState(0)
    const[activePltTwo, setactivePltTwo] = useState(0)
    const[activePltThree, setactivePltThree] = useState(0)

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/status", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(str=>{
            setcompany(str)
            settotalPltOne(str[0].totalPltOne)
            settotalPltTwo(str[0].totalPltTwo)
            settotalPltThree(str[0].totalPltThree)
            
            setcurrentPltOne(str[0].currentPltOne)
            setcurrentPltTwo(str[0].currentPltTwo)
            setcurrentPltThree(str[0].currentPltThree)

            setactivePltOne(str[0].activePltOne)
            setactivePltTwo(str[0].activePltTwo)
            setactivePltThree(str[0].activePltThree)
            
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_mc", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(mc=>{
            setmc(mc)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_ld", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(ld=>{
            setld(ld)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_others", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(others=>{
            setothers(others)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_esi", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(esi=>{
            setesi(esi)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_rmj", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(rmj=>{
            setrmj(rmj)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_rso", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(rso=>{
            setrso(rso)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_remarks", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(remark=>{
            setremarks(remark)
        })
        .catch(error=>console.log(error))

        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_to", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(to=>{
            settimeoff(to)
        })
        .catch(error=>console.log(error))
      }
    
    useEffect(() => {
        loadData()
      },[])

    const getIDName = (mc, plt) =>
        mc.reduce((acc, item) => {
            if (item.platoon===plt) {
            acc.push(<li key={item.leave_id}>{item.id} {item.name}</li>);
        }
        return acc;
    }, []);

    const getRemarks = (remarks, plt) =>
        remarks.reduce((acc, item) => {
            if (item.platoon===plt) {
            acc.push(<li key={item.leave_id}>{item.id} {item.name}: {item.remark}</li>);
        }
        return acc;
    }, []);

    const getOthers = (others, plt) =>
        others.reduce((acc, item) => {
            if (item.platoon===plt) {
            acc.push(<li key={item.leave_id}>{item.id} {item.name} : {item.type}</li>);
        }
        return acc;
    }, []);

    const getESI = (esi, plt) =>
        esi.reduce((acc, item) => {
            if (item.platoon===plt && item.esi_back===false) {
            acc.push(<li key={item.leave_id}>{item.id} {item.name}</li>);
        }
        return acc;
    }, []);

    return (
        <div class >
            <BasicExample></BasicExample>
            <br></br>
            <br></br>
            <br></br>
            <h1 align="center">Charlie</h1>
            {company && company.map(str => {
                return (
                    <div key={str.totalPltOne}>
                        <p>Company TS: {str.totalPltOne+str.totalPltTwo+str.totalPltThree}</p>
                        <p>Company CS: {str.currentPltOne+str.currentPltTwo+str.currentPltThree}</p>
                        <p>Company MC: {str.companyMCCount}</p>
                        <p>Company RSO: {str.companyRSOCount}</p>
                        <p>Company ESI: {str.companyESICount}</p>
                        <p>Others: {str.companyOthersCount}</p>
                        <ul>
                            {Object.keys(str.others_dic).map(other => (
                                <li key={other}>{other}: {str.others_dic[other]}</li>
                            ))}
                        </ul>
                    </div>
                )
            })}
            <hr></hr>
            <h1 align="center">C1</h1>
            <p>TS: {totalPltOne}</p>
            <p>CS: {currentPltOne}</p>
            <p>AS: {activePltOne}</p>
            {getIDName(mc, 1).length!==0 && <p>MC</p>}
            {getIDName(mc, 1).length!==0 && <ul>{getIDName(mc, 1)}</ul>}
            {getIDName(ld, 1).length!==0 && <p>LD</p>}
            {getIDName(ld, 1).length!==0 && <ul>{getIDName(ld, 1)}</ul>}
            {getESI(esi, 1).length!==0 && <p>ESI</p>}
            {getESI(esi, 1).length!==0 && <ul>{getESI(esi, 1)}</ul>}
            {getIDName(rmj, 1).length!==0 && <p>RMJ</p>}
            {getIDName(rmj, 1).length!==0 && <ul>{getIDName(rmj, 1)}</ul>}
            {getIDName(rso, 1).length!==0 && <p>RSO</p>}
            {getIDName(rso, 1).length!==0 && <ul>{getIDName(rso, 1)}</ul>}
            {getIDName(timeoff, 1).length!==0 && <p>Time Off</p>}
            {getIDName(timeoff, 1).length!==0 && <ul>{getIDName(timeoff, 1)}</ul>}
            {getOthers(others, 1).length!==0 && <p>Others</p>}
            {getOthers(others, 1).length!==0 && <ul>{getOthers(others, 1)}</ul>}
            {getRemarks(remarks, 1).length!==0 && <p>Remarks</p>}
            {getRemarks(remarks, 1).length!==0 && <ul>{getRemarks(remarks, 1)}</ul>}


            <hr></hr>
            <h1 align="center">C2</h1>
            <p>TS: {totalPltTwo}</p>
            <p>CS: {currentPltTwo}</p>
            <p>AS: {activePltTwo}</p>
            {getIDName(mc, 2).length!==0 && <p>MC</p>}
            {getIDName(mc, 2).length!==0 && <ul>{getIDName(mc, 2)}</ul>}
            {getIDName(ld, 2).length!==0 && <p>LD</p>}
            {getIDName(ld, 2).length!==0 && <ul>{getIDName(ld, 2)}</ul>}
            {getESI(esi, 2).length!==0 && <p>ESI</p>}
            {getESI(esi, 2).length!==0 && <ul>{getESI(esi, 2)}</ul>}
            {getIDName(rmj, 2).length!==0 && <p>RMJ</p>}
            {getIDName(rmj, 2).length!==0 && <ul>{getIDName(rmj, 2)}</ul>}
            {getIDName(rso, 2).length!==0 && <p>RSO</p>}
            {getIDName(rso, 2).length!==0 && <ul>{getIDName(rso, 2)}</ul>}
            {getIDName(timeoff, 2).length!==0 && <p>Time Off</p>}
            {getIDName(timeoff, 2).length!==0 && <ul>{getIDName(timeoff, 2)}</ul>}
            {getOthers(others, 2).length!==0 && <p>Others</p>}
            {getOthers(others, 2).length!==0 && <ul>{getOthers(others, 2)}</ul>}
            {getRemarks(remarks, 2).length!==0 && <p>Remarks</p>}
            {getRemarks(remarks, 2).length!==0 && <ul>{getRemarks(remarks, 2)}</ul>}

            <hr></hr>
            <h1 align="center">C3</h1>
            <p>TS: {totalPltThree}</p>
            <p>CS: {currentPltThree}</p>
            <p>AS: {activePltThree}</p>
            {getIDName(mc, 3).length!==0 && <p>MC</p>}
            {getIDName(mc, 3).length!==0 && <ul>{getIDName(mc, 3)}</ul>}
            {getIDName(ld, 3).length!==0 && <p>LD</p>}
            {getIDName(ld, 3).length!==0 && <ul>{getIDName(ld, 3)}</ul>}
            {getESI(esi, 3).length!==0 && <p>ESI</p>}
            {getESI(esi, 3).length!==0 && <ul>{getESI(esi, 3)}</ul>}
            {getIDName(rmj, 3).length!==0 && <p>RMJ</p>}
            {getIDName(rmj, 3).length!==0 && <ul>{getIDName(rmj, 3)}</ul>}
            {getIDName(rso, 3).length!==0 && <p>RSO</p>}
            {getIDName(rso, 3).length!==0 && <ul>{getIDName(rso, 3)}</ul>}
            {getIDName(timeoff, 3).length!==0 && <p>Time Off</p>}
            {getIDName(timeoff, 3).length!==0 && <ul>{getIDName(timeoff, 3)}</ul>}
            {getOthers(others, 3).length!==0 && <p>Others</p>}
            {getOthers(others, 3).length!==0 && <ul>{getOthers(others, 3)}</ul>}
            {getRemarks(remarks, 3).length!==0 && <p>Remarks</p>}
            {getRemarks(remarks, 3).length!==0 && <ul>{getRemarks(remarks, 3)}</ul>}
        </div>
        
    )
}

export default StatusToday

