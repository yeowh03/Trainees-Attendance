import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import attPic from "../att.png"

function BasicExample() {
  return (
    <Navbar expand="lg" bg="light" className="navbar fixed-top">
        <Container>
            <Navbar.Brand>
              <img src={attPic}
                width="30"
                height="30"
                className="d-inline-block align-top"
                style={{marginRight:5}}></img>Charlie Attendance
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                    <Nav.Link href="/">Home</Nav.Link>
                    <Nav.Link href="/StatusToday">Status</Nav.Link>
                    <Nav.Link href="/trackmccount">MC</Nav.Link>
                </Nav>
            </Navbar.Collapse>
        </Container>
    </Navbar>
  );
}

export default BasicExample;