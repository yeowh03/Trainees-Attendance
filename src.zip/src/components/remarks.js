import React, { useEffect, useState } from "react"
import { Fab, Action } from 'react-tiny-fab';
import { IoIosAdd } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2"
import Button from 'react-bootstrap/Button'

function RemarksToday(props) {

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const deleteRemark = (remark_id, name, id) => {
        Swal.fire({
            title: "Are you sure?",
            text: "Removing "+id+" "+name+" 's Remark",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"

          }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Deleted!",
                    text: "Remark has been deleted.",
                    icon: "success",
                });

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/delete_remarks", {
                    method:"DELETE",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({remark_id:remark_id})
                })
                    .then(resp => resp.json())
                    .then(data => loadData())
                    .catch(error => {
                        console.log(error)
                    
                    })
            }
        });          
        
    }

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_remarks", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(remark=>{
            setData(remark)
        })
        .catch(error=>console.log(error))
      }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div>
            <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate("/")}>Back</Button>
            <h1 align="center">Remarks</h1>
            <p align="center" style={{fontSize:"20px"}}>Total: {data.length}</p>
            {data && data.map(remark => {
                return (
                    <div key={remark.remark_id}>
                        <h5>{remark.id} {remark.name}</h5>
                        <p>{remark.remark}</p>

                        <div className="row">
                            <div className="col-4">
                                <button className="btn btn-primary"
                                onClick = {() => navigate("/idOnlyForm", {state:{leave:{
                                    name:remark.name, 
                                    id:remark.id, 
                                    remark_id:remark.remark_id,
                                    remark:remark.remark,
                                    type:"Remarks"
                                }}})}
                                >Update</button>                  
                            </div>

                            <div className="col-4">
                                <button className="btn btn-danger"
                                onClick={() => deleteRemark(remark.remark_id, remark.name, remark.id)}
                                >Delete</button>                  
                            </div>
                        </div>
                        <hr></hr>
                    </div>
                )
            })}
            <Fab mainButtonStyles={{backgroundColor:"orange"}} style={{bottom:5, right:5}}
            icon={<IoIosAdd style={{color:"white"}}/>}
            onClick={() => {
                navigate("/idOnlyForm", {state:{leave:{id:"", remark:"", type:"Remarks"}}})
            }}
            />
        
        </div>
        
    )
}

export default RemarksToday

