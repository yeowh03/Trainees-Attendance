import React, { useEffect, useState } from "react"
import { Fab } from 'react-tiny-fab';
import { IoIosAdd } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2"
import Button from 'react-bootstrap/Button'

function OthersToday(props) {

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const deleteOthers = (leave_id, name, id, type) => {
        Swal.fire({
            title: "Are you sure?",
            text: "Removing "+id+" "+name+" 's "+type,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"

          }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Deleted!",
                    text: type+" has been deleted.",
                    icon: "success",
                });

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/delete_others", {
                    method:"DELETE",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({leave_id:leave_id})
                })
                    .then(resp => resp.json())
                    .then(data => loadData())
                    .catch(error => {
                        console.log(error)
                    
                    })
            }
        });          
        
    }

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_others", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(others=>{
            setData(others)
        })
        .catch(error=>console.log(error))
      }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div>
            <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate("/")}>Back</Button>
            <h1 align="center">Others</h1>
            <p align="center" style={{fontSize:"20px"}}>Total: {data.length}</p>
            {data && data.map(others => {
                return (
                    <div key={others.leave_id}>
                        <h5>{others.id} {others.name}</h5>
                        <p>{others.startDate} - {others.endDate}</p>
                        {others.inCamp && others.active ? <p>Active</p> : null}
                        {!others.inCamp ? <p>Absent</p> : null}
                        {others.inCamp && !others.active ? <p>Present, Not Active</p> : null}

                        <div className="row">
                            <div className="col-4">
                                <button className="btn btn-primary"
                                onClick = {() => navigate("/MCForm", {state:{leave:{
                                    id:others.id, 
                                    startDate:others.startDate, 
                                    endDate:others.endDate, 
                                    leave_id:others.leave_id, 
                                    type:others.type,
                                    inCamp:others.inCamp,
                                    active:others.active
                                    }}})}
                                >Update</button>                  
                            </div>

                            <div className="col-4">
                                <button className="btn btn-danger"
                                onClick={() => deleteOthers(others.leave_id, others.name, others.id, others.type)}
                                >Delete</button>                  
                            </div>
                        </div>
                        <hr></hr>
                    </div>
                )
            })}
            <Fab mainButtonStyles={{backgroundColor:"orange"}} style={{bottom:5, right:5}}
            icon={<IoIosAdd style={{color:"white"}}/>}
            onClick={() => {
                navigate("/MCForm", {state:{leave:{id:"", startDate:"", endDate:"", leave_id:"", type:"", inCamp:"", active:""}}})
            }}
            />
        
        </div>
        
    )
}

export default OthersToday

