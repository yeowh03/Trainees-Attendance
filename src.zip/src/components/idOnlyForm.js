import Button from 'react-bootstrap/Button'
import React, {useState} from "react"
import { useLocation, useNavigate } from "react-router-dom"


function IDOnlyForm(props) { 
    const location = useLocation()
    const navigate = useNavigate()
    const [id, setid] = useState(location.state.leave.id.toString())
    const [errors, seterrors] = useState({})
    const [type, settype] = useState(location.state.leave.type)
    const [remark, setremark] = useState(location.state.leave.remark)
    const [remark_id, setremark_id] = useState(location.state.leave.remark_id)
    const [updateRemark, setupdateRemark] = useState(id ? true : false)

    const validateForm = () => {
        let errors_dic = {}
        if (!id || id.length !== 4 || isNaN(id)) errors_dic.id = "Invalid ID."

        if (type==="Remarks") {
            if (!remark) errors_dic.remark = "Remark is required."
        }

        seterrors(errors_dic)
        return Object.keys(errors_dic).length === 0
    }

    const handleRSOSubmit = (props) => {
        if (validateForm()) {        
            fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_rso", {
                method:"PUT",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({id:id})
            })

            .then(resp => resp.json())

            .then(data => {
                navigate("/RSOToday")
            })
            .catch(error => 
                console.log(error)
            )       
        }

        else {
            console.log("UnSuccessful")
        }    
    }

    const handleTOSubmit = (props) => {
        if (validateForm()) {        
            fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_to", {
                method:"POST",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({id:id})
            })

            .then(resp => resp.json())

            .then(data => {
                navigate("/TOToday")
            })
            .catch(error => 
                console.log(error)
            )       
        }

        else {
            console.log("UnSuccessful")
        }    
    }

    const handleESISubmit = (props) => {
        if (validateForm()) {        
            fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_esi", {
                method:"PUT",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({id:id})
            })

            .then(resp => resp.json())

            .then(data => {
                navigate("/ESIToday")
            })
            .catch(error => 
                console.log(error)
            )       
        }

        else {
            console.log("UnSuccessful")
        }    
    }

    const handleRemarksSubmit = (props) => {
        if (validateForm()) 
            if (!updateRemark)
                {        
                    fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/add_remarks", {
                        method:"POST",
                        headers:{
                            "Content-Type":"application/json"
                        },
                        body:JSON.stringify({id:id, remark:remark})
                    })

                    .then(resp => resp.json())

                    .then(data => {
                        navigate("/RemarksToday")
                    })
                    .catch(error => 
                        console.log(error)
                    )       
                }

            else {
                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_remarks", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id, remark:remark, remark_id:remark_id})
                })

                .then(resp => resp.json())

                .then(data => {
                    navigate("/RemarksToday")
                })
                .catch(error => 
                    console.log(error)
                )
            }

        else {
            console.log("UnSuccessful")
        }
    }
    
    return (
        <div>
            <div className="mb-3">
                <label htmlFor="id" className="form-label">4D</label>
                <input type="text" style={{marginBottom:"10px"}} className="form-control" placeholder="1301" value={id.toString()} onChange={(e) => setid(e.target.value)}/>
                {errors.id ? <p style={{paddingLeft:10, color:"red"}}>{errors.id}</p> : null}

                {type==="Remarks" && <label htmlFor="remark" className="form-label">Remark</label>}
                {type==="Remarks" && 
                <textarea 
                    rows="5" 
                    value={remark} 
                    onChange={(e)=>setremark(e.target.value)}
                    className='form-control'
                    placeholder="Please enter remark"
                    style={{marginBottom:"10px"}}
                />}
                {errors.remark ? <p style={{paddingLeft:10, color:"red"}}>{errors.remark}</p> : null}
            
                <div className="d-grid gap-2">
                    {type==="RSO" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleRSOSubmit}>Submit</Button>
                    }

                    {type==="TO" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleTOSubmit}>Submit</Button>
                    }

                    {type==="Remarks" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleRemarksSubmit}>Submit</Button>
                    }

                    {type==="ESI" && 
                        <Button style={{marginTop:"10px"}} variant="success"
                        onClick={handleESISubmit}>Submit</Button>
                    }
                </div>
            </div>

            <div className="d-grid gap-2">
                    <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate(-1)}>Back</Button>
            </div>  
        </div>
    )
}
export default IDOnlyForm