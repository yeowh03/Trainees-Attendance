import React, { useEffect, useState } from "react"
import { Fab, Action } from 'react-tiny-fab';
import { IoIosAdd } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2"
import Button from 'react-bootstrap/Button'

function ESIToday(props) {

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const deleteESI = (id, name) => {
        Swal.fire({
            title: "Are you sure?",
            text: "Removing "+id+" "+name+" 's ESI",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"

          }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Deleted!",
                    text: "ESI has been deleted.",
                    icon: "success",
                });

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/delete_esi", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({id:id})
                })
                    .then(resp => resp.json())
                    .then(data => loadData())
                    .catch(error => {
                        console.log(error)           
                    }) 
                }})
              
    }

    const updateESI = (id) => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/esi_entry", {
            method:"PUT",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({id:id})
        })
            .then(resp => resp.json())
            .then(data => loadData())
            .catch(error => {
                console.log(error)
            
            })       
    }

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_esi", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(esi=>{
            setData(esi)
        })
        .catch(error=>console.log(error))
      }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div>
            <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate("/")}>Back</Button>
            <h1 align="center">ESI</h1>
            <p align="center" style={{fontSize:"20px"}}>Total: {data.length}</p>
            {data && data.map(esi => {
                return (
                    <div key={esi.id}>
                        <h5>{esi.id} {esi.name}</h5>

                        <div className="row">
                            <div className="col-4">
                                <button className="btn btn-danger"
                                onClick={() => deleteESI(esi.id, esi.name)}
                                >Delete</button>                  
                            </div>

                            <div className="col-5">
                                {!esi.esi_back && 
                                    <button className="btn btn-success"
                                    onClick={() => updateESI(esi.id)}
                                >Book In</button>}

                                {esi.esi_back && 
                                    <button className="btn btn-warning"
                                    onClick={() => updateESI(esi.id)}
                                >Book Out</button>}                                  
                            </div>
                        </div>
                        <hr></hr>
                    </div>
                )
            })}
            <Fab mainButtonStyles={{backgroundColor:"orange"}} style={{bottom:5, right:5}}
            icon={<IoIosAdd style={{color:"white"}}/>}
            onClick={() => {
                navigate("/idOnlyForm", {state:{leave:{id:"", type:"ESI"}}})
            }}
            />
        
        </div>
        
    )
}

export default ESIToday