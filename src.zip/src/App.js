import './App.css';
import { Route, Routes, BrowserRouter } from "react-router-dom"
import Home from './components/home';
import MCToday from './components/mc-today';
import MCForm from './components/mcForm';
import LDToday from './components/ld-today';
import RMJToday from './components/rmj-today';
import RSOToday from './components/rso-today';
import IDOnlyForm from './components/idOnlyForm';
import TOToday from './components/timeoff-today';
import OthersToday from './components/others-today';
import RemarksToday from './components/remarks';
import ESIToday from './components/esi-today';
import StatusToday from './components/status';
import TrackMCCount from './components/trackmccount';
import MCHistory from './components/mcHistory';

function App() {

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/MCToday" element={<MCToday/>} />
          <Route path="/MCForm" element={<MCForm/>} />
          <Route path="/LDToday" element={<LDToday/>} />
          <Route path="/RMJToday" element={<RMJToday/>} />
          <Route path="/idOnlyForm" element={<IDOnlyForm/>} />
          <Route path="/RSOToday" element={<RSOToday/>} />
          <Route path="/TOToday" element={<TOToday/>} />
          <Route path="/OthersToday" element={<OthersToday/>} />
          <Route path="/RemarksToday" element={<RemarksToday/>} />
          <Route path="/ESIToday" element={<ESIToday/>} />
          <Route path="/StatusToday" element={<StatusToday/>} />
          <Route path="/trackmccount" element={<TrackMCCount/>} />
          <Route path="/mcHistory" element={<MCHistory/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
