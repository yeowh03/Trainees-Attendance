import React, { useEffect, useState } from "react"
import { useLocation } from "react-router-dom";
import BasicExample from "./navbar";

function MCHistory(props) {

    const location = useLocation()
    const [data, setData] = useState([])
    const [id, setid] = useState(location.state.id)

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/mc_history", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(dates=>{
            setData(dates)
        })
        .catch(error=>console.log(error))
      }
    
    useEffect(() => {
        loadData()
      },[])

    const getDates = (dates, id) =>
        dates.reduce((acc, item) => {
            if (item.id===id) {
            acc.push(<li key={item.leave_id}>{item.startDate} - {item.endDate}</li>);
            }
        return acc;
        }, []);

    return (
        <div>
            <BasicExample></BasicExample>
            <br></br>
            <br></br>
            <h1 align="center">MC History</h1>
            <ul>{getDates(data, id)}</ul>
        </div>
    )
}

export default MCHistory