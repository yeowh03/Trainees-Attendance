import React from "react"
import Button from 'react-bootstrap/Button'
import { useNavigate } from "react-router-dom";
import BasicExample from "./navbar";

function Home() {
    const navigate = useNavigate()

    return (
        
        <div className="App">
            <br></br>
            <br></br>
            <BasicExample></BasicExample>
            <h1 align="center" style={{"marginBottom":20}}>Types</h1>
            <div className="d-grid gap-2">
                <Button type="button" variant="success" 
                onClick={() => navigate("/MCToday")}>MC</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button" variant="success"
                onClick={() => navigate("/LDToday", {state:{type:"LD"}})}>LD</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button" variant="success"
                onClick={() => navigate("/RSOToday", {state:{type:"RSO"}})}>RSO</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button"  variant="success"
                onClick={() => navigate("/TOToday", {state:{type:"TO"}})}>Time Off</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button" variant="success"
                onClick={() => navigate("/RMJToday", {state:{type:"RMJ"}})}>RMJ</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button"  variant="success"
                onClick={() => navigate("/ESIToday", {state:{type:"ESI"}})}>ESI</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button" variant="success"
                onClick={() => navigate("/OthersToday")}>Others</Button>
            </div>
            <br></br>
            <div className="d-grid gap-2">
                <Button type="button"  variant="success"
                onClick={() => navigate("/RemarksToday")}>Remarks</Button>
            </div>
            
        </div>
    );
  }
  
export default Home;