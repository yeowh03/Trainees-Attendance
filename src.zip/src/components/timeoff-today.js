import React, { useEffect, useState } from "react"
import { Fab, Action } from 'react-tiny-fab';
import { IoIosAdd } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2"
import Button from 'react-bootstrap/Button'

function TOToday(props) {

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const deleteTO = (timeoff_id, name, id) => {
        Swal.fire({
            title: "Are you sure?",
            text: "Deleting "+id+" "+name+"'s Time Off",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"

          }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Deleted!",
                    text: "Your entry has been deleted.",
                    icon: "success",
                });

                console.log(timeoff_id, "TIMEOFFID")

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/delete_to", {
                    method:"DELETE",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({timeoff_id:timeoff_id})
                })
                    .then(resp => resp.json())
                    .then(data => loadData())
                    .catch(error => {
                        console.log(error)
                    
                    })
            }
        });          
        
    }

    const updateTO = (timeoff_id, name, id) => {
        Swal.fire({
            title: "Are you sure?",
            text: id+" "+name+" has returned.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes!"

          }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Time Off ended!",
                    text: "Your entry has been recorded.",
                    icon: "success",
                });

                console.log(timeoff_id, "TIMEOFFID")

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/edit_to", {
                    method:"PUT",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({timeoff_id:timeoff_id})
                })

                .then(resp => resp.json())

                .then(data => {
                    loadData()
                })
                .catch(error => 
                    console.log(error)
                )
            }
        });
              
    }

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_to", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(to=>{
            setData(to)
        })
        .catch(error=>console.log(error))
    }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div>
            <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate("/")}>Back</Button>
            <h1 align="center">Time Off</h1>
            <p align="center" style={{fontSize:"20px"}}>Total: {data.length}</p>
            {data && data.map(to => {
                return (
                    <div key={to.timeoff_id}>
                        <h5>{to.id} {to.name}</h5>

                        <div className="row">
                            <div className="col-4">
                                <button className="btn btn-success"
                                onClick={() => updateTO(to.timeoff_id, to.name, to.id)}
                                >Book In</button>                  
                            </div>

                            <div className="col-4">
                                <button className="btn btn-danger"
                                onClick={() => deleteTO(to.timeoff_id, to.name, to.id)}
                                >Delete</button>                  
                            </div>                      
                        </div>
                        <hr></hr>
                    </div>
                )
            })}
            <Fab mainButtonStyles={{backgroundColor:"orange"}} style={{bottom:5, right:5}}
            icon={<IoIosAdd style={{color:"white"}}/>}
            onClick={() => {
                navigate("/idOnlyForm", {state:{leave:{id:"", type:"TO"}}})
            }}
            />
        
        </div>
        
    )
}

export default TOToday