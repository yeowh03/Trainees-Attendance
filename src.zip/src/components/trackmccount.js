import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import BasicExample from "./navbar";
import Card from 'react-bootstrap/Card';

function TrackMCCount(props) {

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/track", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(rso=>{
            setData(rso)
        })
        .catch(error=>console.log(error))
      }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div>
            <BasicExample></BasicExample>
            <br></br>
            <br></br>
            <h1 align="center" style={{marginBottom:10}}>MC Count</h1>
            {data && data.map(rec => {
                return (
                    <div key={rec.id} style={{display:"flex"}} onClick={() => navigate("/mcHistory", {state:{id:rec.id}})}>
                        <Card bg="light" text="dark" className="mb-3" style={{flex:1}}>
                            <Card.Header as="h5">{rec.id} {rec.name}</Card.Header>
                            <Card.Body>
                                <Card.Text>Total: {rec.duration}</Card.Text>
                            </Card.Body>
                        </Card>
                    </div>
                )
            })}      
        </div>
        
    )
}

export default TrackMCCount