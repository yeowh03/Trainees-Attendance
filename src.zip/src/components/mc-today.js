import React, { useEffect, useState } from "react"
import { Fab, Action } from 'react-tiny-fab';
import { IoIosAdd } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2"
import Button from 'react-bootstrap/Button'

function MCToday(props) {
    console.log("MCTODAY IS GAYYYYYY")

    const navigate = useNavigate()
    const [data, setData] = useState([])

    const deleteMC = (leave_id, name, id) => {
        Swal.fire({
            title: "Are you sure?",
            text: "Removing "+id+" "+name+" 's MC",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"

          }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Deleted!",
                    text: "MC has been deleted.",
                    icon: "success",
                });

                fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/delete_mc", {
                    method:"DELETE",
                    headers:{
                        "Content-Type":"application/json"
                    },
                    body:JSON.stringify({leave_id:leave_id})
                })
                    .then(resp => resp.json())
                    .then(data => loadData())
                    .catch(error => {
                        console.log(error)
                    
                    })
            }
        });          
        
    }

    const loadData = () => {
        fetch("https://glacial-falls-17702-9b8309e416b8.herokuapp.com/get_mc", {
            "method":"GET",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(resp=>resp.json())
        .then(mc=>{
            setData(mc)
        })
        .catch(error=>console.log(error))
      }
    

    useEffect(() => {
        loadData()
      },[])


    return (
        <div style={{flex:1}}>
            <Button style={{marginTop:"10px"}} variant="light"
                    onClick={() => navigate("/")}>Back</Button>
            <h1 align="center">MC</h1>
            <p align="center" style={{fontSize:"20px"}}>Total: {data.length}</p>
            {data && data.map(mc => {
                return (
                    <div key={mc.leave_id}>
                        <h5>{mc.id} {mc.name}</h5>
                        <p>{mc.startDate} - {mc.endDate}</p>

                        <div className="row">
                            <div className="col-4">
                                <button className="btn btn-primary"
                                onClick = {() => navigate("/MCForm", {state:{leave:{
                                    name:mc.name, 
                                    id:mc.id, 
                                    startDate:mc.startDate, 
                                    endDate:mc.endDate, 
                                    leave_id:mc.leave_id, 
                                    type:"MC",
                                    inCamp:"",
                                    active:""}}})}
                                >Update</button>                  
                            </div>

                            <div className="col-4">
                                <button className="btn btn-danger"
                                onClick={() => deleteMC(mc.leave_id, mc.name, mc.id)}
                                >Delete</button>                  
                            </div>
                        </div>
                        <hr></hr>
                    </div>
                )
            })}
            <Fab mainButtonStyles={{backgroundColor:"orange"}} style={{bottom:5, right:5, position:"fixed"}} 
            icon={<IoIosAdd style={{color:"white"}}/>}
            onClick={() => {
                navigate("/MCForm", {state:{leave:{name:"", id:"", startDate:"", endDate:"", leave_id:"", inCamp:"", active:"",type:"MC"}}})
            }}
            />
        
        </div>
        
    )
}

export default MCToday

